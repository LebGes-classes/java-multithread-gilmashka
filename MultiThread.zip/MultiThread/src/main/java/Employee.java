import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

class Employee implements Runnable {
    private int id;
    private String name;
    private Queue<Integer> tasks;
    private int totalWorkTime = 0;
    private int idleTime = 0;
    private int tasksCompleted = 0;
    private int daysWorked = 0;

    public Employee(int id, String name, List<Integer> tasks) {
        this.id = id;
        this.name = name;
        this.tasks = new LinkedList<>(tasks);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getTotalWorkTime() {
        return totalWorkTime;
    }

    public int getIdleTime() {
        return idleTime;
    }

    public int getTasksCompleted() {
        return tasksCompleted;
    }

    public Queue<Integer> getTasks() {
        return tasks;
    }

    @Override
    public void run() {
        System.out.println(name + " начал работать...");

        while (!tasks.isEmpty()) {
            daysWorked++;
            int remainingDayTime = 8;
            int currentTask = tasks.poll();

            if (currentTask <= remainingDayTime) {
                totalWorkTime += currentTask;
                idleTime += remainingDayTime - currentTask;
                remainingDayTime -= currentTask;
                tasksCompleted++;
            } else {
                totalWorkTime += remainingDayTime;
                tasks.add(currentTask - remainingDayTime);
                remainingDayTime = 0;
            }

            if (!tasks.isEmpty()) {
                System.out.println(name + " переносит оставшиеся задачи на следующий день.");
            }
        }

        // Расчет эффективности (средняя за все дни)
        double efficiency = (double) totalWorkTime / (daysWorked * 8) * 100;
        System.out.printf("%s: %dч работы, %dч простоя, %d задач выполнено, эффективность: %.2f%%\n",
                name, totalWorkTime, idleTime, tasksCompleted, efficiency);
    }
}